from setuptools import setup

setup(

	name="PaqueteCalculos",
	version="1.0",
	description="Paquete de Redondeo Y Potencia",
	author="Enrique",
	author_email="enriq_1997@hotmail.com",
	url="https://github.com/endaniel1/Aprendiendo_Python",
	packages=["Calculos","Calculos.Redondeo_Potencia"]

	)