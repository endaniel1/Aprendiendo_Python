def sumar(op1,op2):
	print("El Resultado De La Suma Es: ",op1+op2)
	
def restar(op1,op2):
	print("El Resultado De La Resta Es: ",op1-op2)

def multiplicar(op1,op2):
	print("El Resultado De La Multiplicación Es: ",op1*op2)

def dividir(op1,op2):
	print("El Resultado De La Divición Es: ",op1/op2)	

def potencia(base,exponente):
	print("El Resultado De La Potencia Es: ",base**exponente)	

def redondear(numero):
	print("El Número Se Redondea A: ",round(numero))	