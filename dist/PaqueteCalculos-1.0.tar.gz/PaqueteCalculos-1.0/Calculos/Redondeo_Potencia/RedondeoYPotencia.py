def potencia(base,exponente):
	print("El Resultado De La Potencia Es: ",base**exponente)	

def redondear(numero):
	print("El Número Se Redondea A: ",round(numero))